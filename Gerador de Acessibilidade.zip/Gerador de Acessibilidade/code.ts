figma.showUI(__html__, { width: 400, height: 270 });

interface PluginMessage {
  type: string;
}

async function handleMessage(message: PluginMessage) {
  if (message.type === 'criarNovoFrame') {
    await criarFrameListaFramesSelecionados();
  }
}

figma.ui.onmessage = handleMessage;

figma.on("selectionchange", () => {
  verificarFrameSelecionado();
});

interface CamadaInfo {
  tipo: string;
  nome: string;
}

interface FrameInfo {
  nomeFrame: string;
  camadas: CamadaInfo[];
}

let frameSelecionadoAnterior: string | null = null;
let frameInfoSelecionadoAnterior: FrameInfo | null = null;

async function criarTexto(texto: string): Promise<TextNode> {
  try {
    await figma.loadFontAsync({ family: "Inter", style: "Regular" });
    const textoNode = figma.createText();
    textoNode.fontName = { family: "Inter", style: "Regular" };
    textoNode.characters = texto;
    return textoNode;
  } catch (error) {
    console.error("Erro ao criar texto:", error);
    throw error;
  }
}

function verificarFrameSelecionado() {
  if (figma.currentPage.selection.length > 0) {
    const frameSelecionado = figma.currentPage.selection[0] as FrameNode;
    const idFrameSelecionado = frameSelecionado.id;

    if (idFrameSelecionado !== frameSelecionadoAnterior) {
      const frameInfo: FrameInfo = {
        nomeFrame: frameSelecionado.name,
        camadas: []
      };

      frameSelecionado.children.forEach(child => {
        frameInfo.camadas.push({
          tipo: child.type,
          nome: child.name
        });
      });

      frameInfoSelecionadoAnterior = frameInfo;
      frameSelecionadoAnterior = idFrameSelecionado;

      console.log("Frame selecionado:", frameInfo.nomeFrame);
      console.log("Camadas:");
      frameInfo.camadas.forEach(camada => {
        console.log("- Tipo:", camada.tipo, ", Nome:", camada.nome);
      });
    }
  } else {
    frameSelecionadoAnterior = null;
    frameInfoSelecionadoAnterior = null;
    console.log("Nenhum frame selecionado na página atual.");
  }
}

async function criarFrameListaFramesSelecionados() {
  try {
    if (figma.currentPage.selection.length > 0) {
      const framesSelecionados = figma.currentPage.selection.filter(node => node.type === "FRAME") as FrameNode[];

      const novoFrame = figma.createFrame();
      novoFrame.name = "Lista de Frames Selecionados";
      novoFrame.layoutMode = "VERTICAL";
      novoFrame.resize(793.70, 1122.52);

      const tipoCamadaMap: { [key: string]: string } = {
        "FRAME": "Camada Frame",
        "TEXT": "Camada Text",
        "RECTANGLE": "Camada Rectangle",
        "ELLIPSE": "Camada Ellipse",
        "LINE": "Camada Line",
        "INSTANCE": "Camada Instance",
        "IMAGE": "Camada Image",
        "DEFAULT": "Camada Desconhecida"
      };

      for (const frame of framesSelecionados) {
        const textoFrame = await criarTexto(`Frame: ${frame.name}`);
        novoFrame.appendChild(textoFrame);

        for (const child of frame.children) {
          const tipoCamada = tipoCamadaMap[child.type] || tipoCamadaMap["DEFAULT"];
          const textoCamadaNode = await criarTexto(`   Tipo: ${tipoCamada}, Nome: ${child.name}`);
          novoFrame.appendChild(textoCamadaNode);
        }
      }

      novoFrame.x = 0;
      novoFrame.y = 0;

      figma.currentPage.selection = [novoFrame];
      figma.viewport.scrollAndZoomIntoView([novoFrame]);

      figma.notify("Novo frame criado com a lista dos frames selecionados.");

      figma.currentPage.selection = [];
    } else {
      console.log("Erro: Nenhum frame selecionado na página atual.");
    }
  } catch (error) {
    console.error("Erro ao criar o frame da lista:", error);
    throw error;
  }
}
