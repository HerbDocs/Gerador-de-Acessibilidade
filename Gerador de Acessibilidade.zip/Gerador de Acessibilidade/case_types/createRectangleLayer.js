var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
// Função para criar uma camada do tipo FRAME e retornar uma string indicando o tipo de acessibilidade
export function createRectangleLayer(frame) {
    return __awaiter(this, void 0, void 0, function* () {
        // Aqui você pode adicionar lógica específica para criar uma camada FRAME
        // Por exemplo, você pode definir propriedades de acessibilidade ou adicionar outros elementos à camada
        // Retorna uma string indicando o tipo de acessibilidade
        return "Frame: Isso é lido como um <DIV>";
    });
}
