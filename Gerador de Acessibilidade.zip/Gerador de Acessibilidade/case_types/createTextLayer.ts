// Função para criar uma camada do tipo FRAME e retornar uma string indicando o tipo de acessibilidade
export async function createTextLayer(frame: TextNode): Promise<string> {
    // Aqui você pode adicionar lógica específica para criar uma camada FRAME
    // Por exemplo, você pode definir propriedades de acessibilidade ou adicionar outros elementos à camada

    // Retorna uma string indicando o tipo de acessibilidade
    return "Frame: Isso é lido como um <DIV>";
}
