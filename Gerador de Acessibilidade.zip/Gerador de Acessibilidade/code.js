"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
figma.showUI(__html__, { width: 400, height: 270 });
function handleMessage(message) {
    return __awaiter(this, void 0, void 0, function* () {
        if (message.type === 'criarNovoFrame') {
            yield criarFrameListaFramesSelecionados();
        }
    });
}
figma.ui.onmessage = handleMessage;
figma.on("selectionchange", () => {
    verificarFrameSelecionado();
});
let frameSelecionadoAnterior = null;
let frameInfoSelecionadoAnterior = null;
function criarTexto(texto) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            yield figma.loadFontAsync({ family: "Inter", style: "Regular" });
            const textoNode = figma.createText();
            textoNode.fontName = { family: "Inter", style: "Regular" };
            textoNode.characters = texto;
            return textoNode;
        }
        catch (error) {
            console.error("Erro ao criar texto:", error);
            throw error;
        }
    });
}
function verificarFrameSelecionado() {
    if (figma.currentPage.selection.length > 0) {
        const frameSelecionado = figma.currentPage.selection[0];
        const idFrameSelecionado = frameSelecionado.id;
        if (idFrameSelecionado !== frameSelecionadoAnterior) {
            const frameInfo = {
                nomeFrame: frameSelecionado.name,
                camadas: []
            };
            frameSelecionado.children.forEach(child => {
                frameInfo.camadas.push({
                    tipo: child.type,
                    nome: child.name
                });
            });
            frameInfoSelecionadoAnterior = frameInfo;
            frameSelecionadoAnterior = idFrameSelecionado;
            console.log("Frame selecionado:", frameInfo.nomeFrame);
            console.log("Camadas:");
            frameInfo.camadas.forEach(camada => {
                console.log("- Tipo:", camada.tipo, ", Nome:", camada.nome);
            });
        }
    }
    else {
        frameSelecionadoAnterior = null;
        frameInfoSelecionadoAnterior = null;
        console.log("Nenhum frame selecionado na página atual.");
    }
}
function criarFrameListaFramesSelecionados() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            if (figma.currentPage.selection.length > 0) {
                const framesSelecionados = figma.currentPage.selection.filter(node => node.type === "FRAME");
                const novoFrame = figma.createFrame();
                novoFrame.name = "Lista de Frames Selecionados";
                novoFrame.layoutMode = "VERTICAL";
                novoFrame.resize(793.70, 1122.52);
                const tipoCamadaMap = {
                    "FRAME": "Camada Frame",
                    "TEXT": "Camada Text",
                    "RECTANGLE": "Camada Rectangle",
                    "ELLIPSE": "Camada Ellipse",
                    "LINE": "Camada Line",
                    "INSTANCE": "Camada Instance",
                    "IMAGE": "Camada Image",
                    "DEFAULT": "Camada Desconhecida"
                };
                for (const frame of framesSelecionados) {
                    const textoFrame = yield criarTexto(`Frame: ${frame.name}`);
                    novoFrame.appendChild(textoFrame);
                    for (const child of frame.children) {
                        const tipoCamada = tipoCamadaMap[child.type] || tipoCamadaMap["DEFAULT"];
                        const textoCamadaNode = yield criarTexto(`   Tipo: ${tipoCamada}, Nome: ${child.name}`);
                        novoFrame.appendChild(textoCamadaNode);
                    }
                }
                novoFrame.x = 0;
                novoFrame.y = 0;
                figma.currentPage.selection = [novoFrame];
                figma.viewport.scrollAndZoomIntoView([novoFrame]);
                figma.notify("Novo frame criado com a lista dos frames selecionados.");
                figma.currentPage.selection = [];
            }
            else {
                console.log("Erro: Nenhum frame selecionado na página atual.");
            }
        }
        catch (error) {
            console.error("Erro ao criar o frame da lista:", error);
            throw error;
        }
    });
}
